# حزمة PATCH252 — استعادة قراءة Format بعد تحديث مصدر الوسائط

هذه حزمة تعديل Smali لنسخة PATCH251، وليست مصدر تطبيق Android الأصلي الكامل.

## ما يصلحه التعديل

- إذا مر تحديث لمصدر الفيديو بمصفوفة تنسيقات فارغة، يحتفظ Renderer بآخر `Format` معروف، بما فيه معلومات H.264 High 10 وبيانات التهيئة CSD، بدل تصفيره مباشرة.
- لم يعد `H26410SoftwareRenderer.o()` يتوقف لمجرد أن `currentFormat` فارغ. يسمح له بقراءة `SampleStream` وانتظار `RESULT_FORMAT_READ` الذي يعيد تهيئة Decoder عند وصول التنسيق الفعلي.
- أضيفت سجلات `CinemanaDecoderPolicy` عند استقبال تحديث بلا تنسيق، وعند قراءة تنسيق فيديو جديد، وعند نجاح أو فشل تهيئة FFmpeg. الهدف تمييز deadlock بسبب Format مفقود من فشل فك الترميز.
- لا تغييرات على `SequentialSubtitleManager` أو حساب مزامنة الترجمة أو الفيديوهات H.264 8-bit.

## إعادة البناء

وفّر Java 17 وأدوات Smali 2.5.2 و`zipalign` و`apksigner.jar` ومفتاح توقيع PATCH251، ثم شغّل:

```bash
export BAKSMALI_JAR=/path/to/baksmali-2.5.2.jar
export SMALI_JAR=/path/to/smali-2.5.2.jar
export ZIPALIGN=/path/to/zipalign
export APKSIGNER_JAR=/path/to/apksigner.jar
export KEYSTORE=/path/to/checkpoint145-debug.keystore
export KEY_ALIAS=androiddebugkey
export KEYSTORE_PASS=android
export KEY_PASS=android
./BUILD_PATCH252.sh /path/to/PATCH251.apk /path/to/PATCH252.apk
```

الملفات الثنائية ومفتاح التوقيع غير مضمّنين داخل هذه الحزمة. ملف APK الجاهز للتجربة متاح منفصلًا.
