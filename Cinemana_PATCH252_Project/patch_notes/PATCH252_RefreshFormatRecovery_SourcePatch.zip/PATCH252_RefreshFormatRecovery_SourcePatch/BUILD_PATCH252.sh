#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 2 ]]; then
  echo "Usage: BUILD_PATCH252.sh PATCH251.apk PATCH252.apk" >&2
  echo "Required env: BAKSMALI_JAR SMALI_JAR ZIPALIGN APKSIGNER_JAR KEYSTORE KEY_ALIAS KEYSTORE_PASS KEY_PASS" >&2
  exit 2
fi
BASE="$(realpath "$1")"
OUT="$(realpath -m "$2")"
: "${BAKSMALI_JAR:?Set BAKSMALI_JAR}"
: "${SMALI_JAR:?Set SMALI_JAR}"
: "${ZIPALIGN:?Set ZIPALIGN}"
: "${APKSIGNER_JAR:?Set APKSIGNER_JAR}"
: "${KEYSTORE:?Set KEYSTORE}"
: "${KEY_ALIAS:?Set KEY_ALIAS}"
: "${KEYSTORE_PASS:?Set KEYSTORE_PASS}"
: "${KEY_PASS:?Set KEY_PASS}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/dex10"
unzip -p "$BASE" classes10.dex > "$TMP/classes10.dex"
java -Xmx1g -jar "$BAKSMALI_JAR" disassemble "$TMP/classes10.dex" -o "$TMP/dex10"
python3 "$ROOT/apply_patch.py" "$TMP/dex10"
java -Xmx1g -jar "$SMALI_JAR" assemble "$TMP/dex10" -o "$TMP/classes10.dex.new"
python3 - "$BASE" "$TMP/classes10.dex.new" "$TMP/unsigned.apk" <<'PY'
from pathlib import Path
import sys, zipfile
base, newdex, out = map(Path, sys.argv[1:])
def is_signature_entry(name):
    u=name.upper()
    if not u.startswith('META-INF/'): return False
    leaf=u.rsplit('/',1)[-1]
    return leaf == 'MANIFEST.MF' or leaf.endswith(('.SF','.RSA','.DSA','.EC'))
with zipfile.ZipFile(base,'r') as src, zipfile.ZipFile(out,'w') as dst:
    replaced=False
    for info in src.infolist():
        if is_signature_entry(info.filename): continue
        data = newdex.read_bytes() if info.filename == 'classes10.dex' else src.read(info.filename)
        if info.filename == 'classes10.dex': replaced=True
        zi=zipfile.ZipInfo(info.filename, info.date_time)
        zi.compress_type=info.compress_type
        zi.external_attr=info.external_attr
        zi.internal_attr=info.internal_attr
        zi.extra=info.extra
        zi.comment=info.comment
        dst.writestr(zi,data,compress_type=info.compress_type,compresslevel=9 if info.compress_type==zipfile.ZIP_DEFLATED else None)
    if not replaced: raise SystemExit('classes10.dex not found in PATCH251 APK')
PY
mkdir -p "$(dirname "$OUT")"
"$ZIPALIGN" -f -p 4 "$TMP/unsigned.apk" "$TMP/aligned.apk"
java -jar "$APKSIGNER_JAR" sign --ks "$KEYSTORE" --ks-key-alias "$KEY_ALIAS" \
  --ks-pass "pass:$KEYSTORE_PASS" --key-pass "pass:$KEY_PASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$OUT" "$TMP/aligned.apk"
java -jar "$APKSIGNER_JAR" verify --verbose --print-certs "$OUT"
"$ZIPALIGN" -c -p 4 "$OUT"
unzip -t "$OUT" | tail -1
echo "Created $OUT"
