#!/usr/bin/env python3
"""Apply PATCH252 refresh-format recovery edits to PATCH251's classes10 smali tree."""
from pathlib import Path
import sys
if len(sys.argv) != 2:
    raise SystemExit("Usage: apply_patch.py <disassembled-classes10-directory>")
root = Path(sys.argv[1])
p = root / "com/shabakaty/cinemana/player/H26410SoftwareRenderer.smali"
if not p.is_file():
    raise SystemExit(f"Renderer smali not found: {p}")
s = p.read_text(encoding="utf-8")
old_guard = '''    iget-object v1, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->currentFormat:Lcom/shabakaty/downloader/wh1;

    if-eqz v1, :cond_ff

    iget-boolean v1, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->ended:Z
'''
new_guard = '''    # Do not gate source reads on currentFormat being non-null. After a MediaSource
    # refresh, onStreamChanged can temporarily provide no formats. The renderer must
    # still read RESULT_FORMAT_READ from its SampleStream or it can remain buffering forever.
    iget-boolean v1, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->ended:Z
'''
if s.count(old_guard) != 1:
    raise SystemExit(f"Expected one currentFormat precondition; found {s.count(old_guard)}")
s = s.replace(old_guard, new_guard, 1)
old_empty = '''    :cond_a
    move-object p1, p4

    :goto_b
'''
new_empty = '''    :cond_a
    const-string v0, "CinemanaDecoderPolicy"

    const-string v1, "Source refresh supplied no video formats; retaining cached Format while awaiting updated stream metadata"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    # Keep the last known codec/profile/CSD across subtitle-only refreshes whose
    # temporary Format[] is empty. The source may not emit a replacement format
    # immediately; the render loop below can still read it if one arrives.
    iget-object p1, p0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->currentFormat:Lcom/shabakaty/downloader/wh1;

    :goto_b
'''
if s.count(old_empty) != 1:
    raise SystemExit(f"Expected one empty-format branch; found {s.count(old_empty)}")
s = s.replace(old_empty, new_empty, 1)
old_format = '''    iput-object v8, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->currentFormat:Lcom/shabakaty/downloader/wh1;

    .line 155
    iget-object v8, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->currentFormat:Lcom/shabakaty/downloader/wh1;

    invoke-direct {p0, v8}, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->configure(Lcom/shabakaty/downloader/wh1;)Z

    .line 156
    goto :goto_fa
'''
new_format = '''    iput-object v8, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->currentFormat:Lcom/shabakaty/downloader/wh1;

    const-string v9, "CinemanaDecoderPolicy"

    const-string v10, "Software renderer received a new video Format from SampleStream"

    invoke-static {v9, v10}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 155
    iget-object v8, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->currentFormat:Lcom/shabakaty/downloader/wh1;

    invoke-direct {p0, v8}, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->configure(Lcom/shabakaty/downloader/wh1;)Z

    iget-boolean v9, v0, Lcom/shabakaty/cinemana/player/H26410SoftwareRenderer;->configured:Z

    if-eqz v9, :cond_cinemana_config_failed

    const-string v9, "CinemanaDecoderPolicy"

    const-string v10, "FFmpeg video decoder configured after stream refresh"

    invoke-static {v9, v10}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_fa

    :cond_cinemana_config_failed
    const-string v9, "CinemanaDecoderPolicy"

    const-string v10, "FFmpeg video decoder configuration failed after stream refresh"

    invoke-static {v9, v10}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 156
    goto :goto_fa
'''
if s.count(old_format) != 1:
    raise SystemExit(f"Expected one format-read block; found {s.count(old_format)}")
s = s.replace(old_format, new_format, 1)
p.write_text(s, encoding="utf-8")
print(f"PATCH252 applied: {p}")
